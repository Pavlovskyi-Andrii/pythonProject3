from flask import Flask,render_template, url_for, request, redirect
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime


app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"]="sqlite:///blog.db"
app.config["SQLALCHEMY_TRECK_MODIFICATIONS"]=False
db =SQLAlchemy(app)


class Article(db.Model):                           # создаем колонки таблицы базы данных
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100),nullable=False)
    intro = db.Column(db.String(300),nullable=False)
    text = db.Column(db.Text, nullable=False)
    date = db.Column(db.DateTime, default= datetime.utcnow)

    def __repr__(self):                         #указіваем какое значение возвращаем с базы данных
        return "<Article %r>" % self.id

@app.route("/")  # що відкриваеться
@app.route("/home")
@app.route("/home/new")
def index():
    return render_template("index.html")


@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact")
def contact():
    return render_template("contact.html")



@app.route("/user/<string:name>/<int:id>")
def user(name,id):
    return "Welcome: "+name+" - "+str(id)


@app.route("/<string:admin>/<string:login>/<int:id>")
def admin(admin,login,id):
    return "Welcome: " +admin+ " - "+login+"-" +str(id)



@app.route("/blog/news")
@app.route("/blog/<int:id>/news")
def news(id):
    return "All news for you: " +str(id)
#/admin-login/id»


@app.route("/posts")
def posts():
    articles=Article.query.order_by(Article.date.desc()).all()
    return render_template("posts.html", articles=articles)


@app.route("/posts/<int:id>")
def post_detail(id):
    article=Article.query.get(id)
    return render_template("post_detail.html", article=article)


@app.route("/create-article", methods=["POST","GET"])
def create_article():
    if request.method == "POST":
        title = request.form["title"]
        intro = request.form["intro"]
        text = request.form["text"]

        article= Article(title =title, intro=intro, text=text )


        try:
            db.session.add(article)
            db.session.commit()
            return redirect("/posts")

        except:
            return ("При додаванні виникла помилка ")
    else:
        return  render_template("create-article.html")







if __name__ == "__main__":
    app.run(debug=True)
